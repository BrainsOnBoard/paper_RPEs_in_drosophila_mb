function N = myincres(M,f,varargin)

if (f - floor(f) ~= 0)
    error('f must be an integer');
end;

h = size(M,1);
w = size(M,2);

if nargin==2
  N = zeros(h*f,w*f);
  for i=1:h
    for j=1:w
      N((i-1)*f+1:i*f,(j-1)*f+1:j*f) = M(i,j);
    end;
  end;
elseif varargin{1}==1
  N = zeros(h*f,w);
  for i=1:h
    N((i-1)*f+1:i*f,:) = repmat(M(i,:),f,1);
  end;
elseif varargin{1}==2
  N = zeros(h,w*f);
  for i=1:w
    N(:,(i-1)*f+1:i*f) = repmat(M(:,i),1,f);
  end;
end;
