function Y = mydecres(X,F)
%
%Y = decres(X,F)
%
%  Decrease the resolution of X by a factor, F. F is a vector, for which
%  F(k) is the factor by which the resolution of X is decreased along 
%  dimension k.

nd = ndims(X);
oldsize = size(X);
newsize = zeros(1,nd);

if isscalar(F)
  F = F * ones(1,nd);
elseif length(F)~=nd
  error('???MYDECRES: F must be a vector of length ndims(X).\n');
end;

for j=1:nd
  newsize(j) = ceil(size(X,j) / F(j));
end;

YY = zeros(prod(newsize),1);

lims = [ones(1,nd); F];

yyind = 1;
d = 1;
while d<=nd  
  while lims(1,d) > oldsize(d)
    lims(1,d) = 1;
    lims(2,d) = F(d);
    d = d + 1;    
    if d>nd
      break;
    else
      lims(1,d) = lims(2,d) + 1;
      lims(2,d) = min(lims(2,d) + F(d),oldsize(d));
    end;
  end;
  if d<=nd
%     fprintf('lims = |%d %d %d|\n',lims(1,:));
%     fprintf('       |%d %d %d|\n\n',lims(2,:));
    ind = mynroi2ind(lims,oldsize);
    YY(yyind) = mean(X(ind));
    yyind = yyind + 1;    
    lims(1,1) = lims(2,1) + 1;
    lims(2,1) = min(lims(2,1) + F(1),oldsize(1));
    d = 1;
  end;
end;

Y = reshape(YY,newsize);