function varargout = mycolorbar(varargin)

c = colorbar;
set(c,'position',[0.83 0.3 0.02 0.4],'fontsize',6);
if nargin>0
  set(get(c,'ylabel'),'rotation',270,'fontsize',8,'fontname','arial','string',varargin{1},'units','normalized','position',[6 0.5 1]);
end;
varargout{1} = c;
