function [lsf param] = my_gauss_fit2(dat)
%
% MY_GAUSS_FIT()
%
% Fit a 1D (2D) Gaussian curve (surface) to vector (image) data. 
% Returns the 1D (2D) least sqaures fit and coefficients.
% COEF = (COORD'*COORD)^-1 * COORD'*DAT; where COORD is the matrix of 
% data points.
%
% Inputs:
% DAT - data to fit
% 
% Outputs:
%  LSF - 1D (2D) least squares fit
% COEF - coefficients for the fit

ny = size(dat,1);
nx = size(dat,2);
 n = nx * ny;

 Y = repmat((1:ny)',[1 nx]); Y = Y(:);
Y2 = Y.^2;
 X = repmat((1:nx),[ny 1]); X = X(:);
X2 = X.^2;
XY = X.*Y;

if ny>1
  f = gaussian([9 9],[1.5 1.5]);
  f = f / sum(f(:));
else
  f = gaussian(3,0.5);
  f = f / sum(f(:));
end;

dat = conv2(dat,f,'same');
dat = abs(dat / max(dat(:)));
dat = dat - 0.99*min(dat(:));

dat = log(dat(:)); % Turn data into column vector


COORD = [X2 Y2 XY X Y ones(n,1)];

coef = eye(size(COORD'*COORD))/(COORD'*COORD) * COORD' * dat;

phi = 0.5 * atan(coef(3) / (coef(1) - coef(2)));
sdy = sqrt(0.5 * (cos(phi)^2 - sin(phi)^2) / ...
           (coef(1) * sin(phi)^2 - coef(2) * cos(phi)^2));
sdx = sqrt(0.5 * (cos(phi)^2 - sin(phi)^2) / ...
           (coef(2) * sin(phi)^2 - coef(1) * cos(phi)^2));         
xo  = (- coef(3)*coef(5) + 2*coef(2)*coef(4)) / ...
      (coef(3)^2 - 4*coef(1)*coef(2));
yo  = (- coef(3)*coef(4) + 2*coef(1)*coef(5)) / ...
      (coef(3)^2 - 4*coef(1)*coef(2));    
c   = exp(coef(6) - coef(1)*xo^2 - coef(3)*xo*yo - coef(2)*yo^2);

param.sdx=[];
param.sdy=[];
param.xo  = xo;
param.yo  = yo;
param.c   = c;
phi = phi / 2 / pi * 360;
if (phi<=0 && coef(1)>coef(2))
  param.phi = abs(phi);
elseif (coef(2) > coef(1))
  param.phi = 90 - phi;
elseif (phi>0 && coef(1)>coef(2))
  param.phi = 180 - phi;
end;
if param.phi<=45
  param.sdx = sdx;
  param.sdy = sdy;
elseif (param.phi>45 && param.phi<135)
  param.sdx = sdy;
  param.sdy = sdx;
elseif (param.phi>135 && param.phi<180)
  param.sdx = sdx;
  param.sdy = sdy;
end;

x = repmat(1:nx,[ny 1]);
y = repmat((1:ny)',[1 nx]);
lsf = 1 / sqrt(2*pi*sdx^2 * 2*pi*sdy^2) * ...
        exp(coef(1)*(x - xo).^2 + coef(3)*(x - xo).*(y - yo) + ...
            coef(2)*(y - yo).^2);
