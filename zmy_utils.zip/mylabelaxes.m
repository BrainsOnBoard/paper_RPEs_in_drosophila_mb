function mylabelaxes(varargin)
%

j = 1;
while j<nargin
  % Set xlabel
  if strcmp(varargin{j},'xlabel')
%     set(get(gca,'xlabel'),'fontsize',8,'fontname','arial','string',varargin{j+1},'interpreter','latex');
    xlabel(varargin{j+1},'fontsize',8,'fontname','arial');
  end;
  % Set ylabel
  if strcmp(varargin{j},'ylabel')
%     set(get(gca,'ylabel'),'fontsize',8,'fontname','arial','string',varargin{j+1},'interpreter','latex');
    ylabel(varargin{j+1},'fontsize',8,'fontname','arial');
  end;
  j = j + 2;
end;
