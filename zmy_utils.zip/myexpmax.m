function out = myexpmax()
%
% MYEXPMAX
%
% Expectation maximisation.

nit = 100;
res = 0.1;
mx = 50;
n = length(0:res:mx);
nd = 2; % # distributions
ns = 1000; % # data samples
alpha = 0.9; % learning rate

% Test data parameters (for 2 bivariate distributions with radially symmetric SDs)
mu = rand(4) * (mx-20) + 10; % Means
sd = rand(2,1) * 5 + 1; % Standard deviations
% Probability of choosing samples form each distribution
pd = [0.8 0.2];


% Real probability distribution 1
[x y] = meshgrid(0:res:mx,0:res:mx);
z1 = res^2 / (2 * pi * sd(1)^2) * exp(-((y - mu(1,1)).^2 + (x - mu(1,2)).^2) / 2 / sd(1)^2);
% Real probability distribution 2
z2 = res^2 / (2 * pi * sd(2)^2) * exp(-((y - mu(2,1)).^2 + (x - mu(2,2)).^2) / 2 / sd(2)^2);
    
% Full mixture distribution
z = pd(1) * z1 + pd(2) * z2;

% Sample data
data = zeros(ns,2);
j = 0;
while j<ns
  r = rand(n);
  rr = r < z;
  srr = sum(rr(:));
  [data(j+1:j+srr,1) data(j+1:j+srr,2)] = find(rr);
  j = j + srr;    
end;
if size(data,1)>ns
  data(ns+1:end,:) = [];
end;
data = data * res;

% Run expectation maximisation
emu = zeros(nd,2,nit);
esd = zeros(nd,nit);
epd = zeros(nd,nit);
emu(:,:,1) = (1 + 0.1*randn(2,1)) * mean(data,1); % Initial estimate of the mus
esd(:,1) = ones(2,1) * mean(std(data,[],1)); % Initial estiamte of the SDs
epd(:,1) = 0.5 * ones(2,1); % Initial estimate of the choice probabilities
for j=2:nit  
  % Likelihood that each data point comes from each estimated distribution
  L = ones(ns,1) * ([epd(1,j-1), epd(2,j-1)] ./ [(2 * pi * esd(1,j-1)^2), (2 * pi * esd(2,j-1)^2)]) .* ...
       [exp(-((data(:,1) - emu(1,1,j-1)).^2 + (data(:,2) - emu(1,2,j-1)).^2)/2/esd(1,j-1)^2), ...
        exp(-((data(:,1) - emu(2,1,j-1)).^2 + (data(:,2) - emu(2,2,j-1)).^2)/2/esd(2,j-1)^2)];
  % Assign distribution IDs to each data point
  [d id] = find(L==(max(L,[],2)*ones(1,2)));
  [d ind] = sort(d,'ascend');
  id = id(ind);
  % Update parameter estimates
  for k=1:nd
    emu(k,:,j) = alpha * emu(k,:,j-1) + (1 - alpha) * mean(data(id==k,:),1);
    esd(k,j) = alpha * esd(k,j-1) + (1 - alpha) * sqrt(mean(std(data(id==k,:),[],1).^2));
    epd(k,j) = alpha * epd(k,j-1) + (1 - alpha) * sum(id==k) / ns;
  end;
  
  % Plot current estimate of distributions
  imagesc(0:res:mx,0:res:mx,z); colormap(1-gray); hold on;
  plot((data(:,2)-1),(data(:,1)-1),'.r');
  for k=1:nd    
    h = myellipse(emu(k,1,j),emu(k,2,j),esd(k,j),esd(k,j),0,gca); 
    set(h,'color',[0 k/nd 1-k/nd]);    
  end;
  hold off;
  pause(0.1); 
  
  % Add noise to avoid local maxima
  emu(:,:,j) = emu(:,:,j) .* (1 + 0.005*randn(nd));
  esd(:,j) = esd(:,j) .* (1 + 0.005*randn(nd,1));
  epd(:,j) = epd(:,j) .* (1 + 0.005*randn(nd,1));
end;

out.emu = emu;
out.esd = esd;
out.epd = epd;
