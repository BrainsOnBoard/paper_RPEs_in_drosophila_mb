function im = myim2red(im)

im = uint8(mean(im,3));
im = cat(3,im,uint8(zeros(size(im,1),size(im,2),2)));