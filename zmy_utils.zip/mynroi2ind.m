function ind = mynroi2ind(lims,fsize)
%
% ind = mynvol2ind(lims,fsize)
%
% Specify an N-dimensional region of interest within an N-dimensional array
% of size FSIZE, and return the linear indeces for all elements within that
% region. LIMS is a 2xN matrix, where LIMS(1,:) are the start indeces in
% each dimension and LIMS(2,:) are the end indeces.
% 
% Inputs:
%   lims - 2xN array specifying start and end indeces for the region of
%          interest. E.g. if the ROI of array X is X(3:4,2:5,4:10) then
%          LIMS = 3 2 4 
%                 4 5 10
%  fsize - the size of the full N-dim array from in which the region of 
%          interest exists, e.g. size(X).
%
% Outputs:
%  ind - linear indeces into the region of interest.

rsize = lims(2,:) - lims(1,:) + 1;
nind = prod(rsize); % # linear indices
nd = size(fsize,2); % # dimensions 

ind = zeros(nind,1,'uint32'); % Init ind array
cii = 1; % Current index into ind
cin = lims(1,2:end); % Current index into N-dim array
d = [1 zeros(1,nd-2)]; % Vector for updating cin
cp = cumprod(fsize(1:(end-1)))';
lims12 = lims(1,1):lims(2,1);

while cii<=nind  
  li = (cin - 1) * cp + lims12;
  ind(cii:(cii+rsize(1)-1)) = li;
  cii = cii + rsize(1);
  flag = 1;
  nc = 1;  
  while flag    
    cin = cin + circshift(d,[0 nc-1]);
    if cin(nc)>lims(2,nc+1)
      cin(nc) = lims(1,nc+1);
      nc = nc + 1;
      if nc>(nd-1)
        flag = 0;
      end;
    else 
      flag = 0;
    end;
  end;  
end;