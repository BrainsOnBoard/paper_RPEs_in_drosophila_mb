function f = mygaussian(dims,sigma)
%
%F = GAUSSIAN(DIMS,SIGMA)
%
%Returns a Gaussian kernel with a standard deviation of SIGMA in F. DIMS is
%a vector specifying the size of F in each dimension (up to 3 dimensions).
if length(dims)==1
  Y = dims;
  indy = 1:Y;
  halfy = (Y+1)/2;
  sigy = sigma;
  
  f = 1 / (sigy * sqrt(2*pi)) * exp(-((indy-halfy)/sigy).^2/2)';
elseif length(dims)==2
  Y = dims(1);
  X = dims(2);
  [indx indy] = meshgrid(1:X,1:Y);
  halfy = (Y+1)/2;
  halfx = (X+1)/2;
  sigy = sigma(1);
  sigx = sigma(2);
  
  %1 / sqrt(2*pi*(sigy^2+sigx^2)) * 
  f = 1 / sqrt(2*pi*sigx^2 * 2*pi*sigy^2) * ...
        exp(-(((indy - halfy)/sigy).^2 + ...
              ((indx - halfx)/sigx).^2)/2);
  
elseif length(dims)==3
  Y = dims(1);
  X = dims(2);
  Z = dims(3);
  [indx indy indz] = meshgrid(1:X,1:Y,1:Z);
  halfy = (Y+1)/2;
  halfx = (X+1)/2;
  halfz = (Z+1)/2;
  sigy = sigma(1);
  sigx = sigma(2);
  sigz = sigma(3);
  
  f = 1 / sqrt((2*pi*sigy^2) * (2*pi*sigx^2) * (2*pi*sigz^2)) * ...
      exp(-(((indy - halfy)/sigy).^2 + ...
            ((indx - halfx)/sigx).^2 + ...
            ((indz - halfz)/sigz).^2)/2);
  %f = f / sum(f(:));
else
  error('???GAUSSIAN: 1<=ndims(size)<=3\n');
end;

