function B = myrot90(A,varargin)
%
% A = MYROT90(I)
% Rotate 2D slice in A counterclockwise by 90 degrees.
%
% Inputs: 
%   A - slice
%   Options:
%     N - # of rotations to apply (default 1)

n = size(A);
if sum(n>1)~=2
  error('***MYIMAGESC: image must be a 2D slice');
end;
n = n(n>1);

B = zeros(n(1),n(2));
B(:,:) = A;

if nargin>1
  N = varargin{1};
  if N==1
    B = rot90(B);
  elseif N==2
    B = rot90(rot90(B));
  elseif N==3
    B = rot90(rot90(rot90(B)));
  end;
else
  B = rot90(B);
end;