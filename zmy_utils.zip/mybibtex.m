function mybibtex(fname)
%
% MYBIBTEX(FNAME)
%
% Opens the file FNAME and modifies the keys to match my file naming format
% for papers: <REV><DATE><1ST AUTHOR>.<LAST AUTHOR>

% Open .bib file
system(['cp ' fname '_old.bib ' fname '.bib']);
bib = fileread([fname '_old.bib']);

oldkey = regexp(bib,'@(article)?(book)?(book section)?(incollection)?(techreport)?\{(?<old>(\w+(-?)\w*))','names');
newkey = regexp(bib,'(?<new>(REV)*(BOOK)*\d\d\d\d(\w+(-?)\w*)\.(\w+(-?)\w*))\.\w\w\w:','names');

oldcell = struct2cell(oldkey(:));
newcell = struct2cell(newkey(:));

bib = regexprep(bib,oldcell,newcell);

fid = fopen([fname '.bib'],'w');
fprintf(fid,'%s',bib);
fclose(fid);

%%% For debugging
% for j=1:length(oldkey) fprintf('%s \t %s \n',oldkey(j).old,newkey(j).new); end;