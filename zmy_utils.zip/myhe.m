function [ehis ebar xtik] = myhe(varargin)
%
% [ehis ebar] = he(a,b,c)
%
% Create vector of edges for use with HISTC and another vector for 
% use with BAR.
%
% a = start value
% b = interval
% c = end value

if nargin>2
  a = varargin{1};
  b = varargin{2};
  c = varargin{3};
  
  ehis = [a:b:(c-b),c+10*eps];
  ebar = a+b/2:b:((c-b)+b/2);  
  xtik = a:b:c;  
  
  if nargin==4
    if varargin{4}
      ebar = [ebar,c+b/2];
      xtik = [xtik,c+b];
    end;
  end;
elseif nargin<=2
  ehis = [varargin{1},inf];
  if nargin==2
    z = varargin{2};
  else
    z = 0;
  end;
  ebar = zeros(length(ehis)-2+z,1);
  for j=1:(length(ebar)-1)
    ebar(j) = (ehis(j) + ehis(j+1)) / 2;
  end;  
  xtik = ehis(1:end-1);  
  if z
    ebar(end) = ehis(end-1) + (ehis(end-1) - ehis(end-2))/2;
    xtik(end) = ehis(end-1) + (ehis(end-1)-ehis(end-2));
  end;
end;
  