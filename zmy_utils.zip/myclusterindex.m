function [score varargout] = myclusterindex(x,id,method)
%
% MYCLUSTERINDEX(X,ID,METHOD)
%
% Inputs:
%       x - data that has been clustered
%      id - vector of cluster labels; length(id) must equal size(x,1)
%  method - integer specifying the clustering score method:
%   1) Calinski-Harabasz
%   2) Davies-Bouldin

% Check if length(id)==size(x,1)
if length(id)~=size(x,1)
  error('??? myclusterindex: length(id) must equal size(x).');
end;

% Check that # clusters exceeds 1
nc = max(id);
if nc<2
  error('??? myclusterindex: number of clusters must exceed 1.');
end;
%% Calinski-Harabasz
if method==1  
  % Number of dimensions
  ndims = size(x,2);
  % Total number of observations
  nobs = size(x,1);
  
  % Global mean
  mu = mean(x,1);
  
  % Compute Between-cluster and Within-cluster variances
  mu_cl = zeros(nc,ndims); % Init cluster means
  n_cl = zeros(nc,1); % Init cluster sizes
  W = 0; % Init Within cluster variance
  for j=unique(id)'
    temp = x(id==j,:);
    mu_cl(j,:) = mean(temp,1);
    n_cl(j) = numel(temp);
    
    W = W + sum(sqrt(sum((temp - ones(size(temp,1),1) * mu_cl(j,:)).^2,2)));
  end;
  
  % Between cluster variance
  B = sum(n_cl .* sqrt(sum((mu_cl - ones(nc,1)*mu).^2,2)));
  
  % Compute CH index
  score = B / W * (nobs - nc) / (nc - 1);
  
  % Outputs
  if nargout>1
    varargout{1} = W;
  end;
  if nargout>2
    varargout{2} = B;
  end;
end;
%% Davies-Bouldin
if method==2
  mu = zeros(nc,size(x,2));% Cluster barycenters
  wcldist = zeros(nc,1); % Mean within cluster distance from barycenter
  for j=1:nc
    mu(j,:) = mean(x(id==j,:),1);
    wcldist(j) = mean(sum(abs(x(id==j,:) - ones(sum(id==j),1)*mu(j,:)),2));
  end;   
  
  bcldist = zeros(nc);
  q = zeros(nc);
  for j=1:nc
    for k=1:nc
      if k~=j
        bcldist(j,k) = sum(abs(mu(j,:) - mu(k,:))); % Between cluster barycenter distances
        q(j,k) = (wcldist(j) + wcldist(k)) / bcldist(j,k);
      end;
    end;
  end;
  qmx = max(q,[],1);
  score = mean(qmx);  
end;