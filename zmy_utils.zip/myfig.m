function h = myfig(varargin)
% 
% hf - scales height relative to width

if nargin==0
  height = 5;
  width = 5;
elseif nargin>=2
  height = varargin{1};
  width = varargin{2};
end;

h = figure('papertype','a4',...
               'units','centimeters',...
               'paperunits','centimeters',...
               'paperposition',[1.5 1.5 width height],...
               'position',[5 5 2*width 2*height]);
						 
if nargin>2
	j = 1;
	while j<(nargin-2)		
		set(h,varargin{j},varargin{j+1});
		j = j + 2;
	end;
end;

set(gca,'fontname','arial','fontsize',6);
set(gca,'position',[0.2 0.2 0.6 0.6]);
