function h = mysweep3d(nw,x,dim,fr,varargin)
%
% h = mysweep3d(nw,x,dim,fr,varargin)
%
% Visual 3D data by sweeping along one dimension, like playing a movie.
% Uses set() to update data, thus enabling user to zoom into specific
% regions and sweep through data within that region only. x can be a cell
% array that contains the 3D data and a handle to the image (provided as
% output from mysweep3d), if the image is already on display.
%
% Inputs:
%  nw - flag to open new figure (1) or play movie with current figure (0)
%   x - 3D data, or cell array with {data handle}
% dim - sweep along this dimension
%  fr - frame rate
%
% Outputs:
%  h - handle to data in the image, 

if nw
  myfig(5,5);
end;

if iscell(x)  
  h = x{2};
  x = x{1};
  clim = [min(x(:)) max(x(:))];
else  
  clim = [min(x(:)) max(x(:))];
  if dim==1
    h = imagesc(squeeze(x(1,:,:)),clim);
  elseif dim==2
    h = imagesc(squeeze(x(:,1,:)),clim);
  elseif dim==3
    h = imagesc(x(:,:,1),clim);
  end;
end;

cmap = jet;
if nargin>4
  cmap = varargin{1};
end;
if nargin>5
  clim = varargin{2};
end;

colormap(cmap);

if dim==1
  for j=1:size(x,dim)
    set(h,'CData',squeeze(x(j,:,:)));    
    set(gca,'clim',clim);
    pause(1/fr);    
    [k t kc] = KbCheck;
    if strcmp(KbName(kc),'q')
      break;
    end;
  end;
elseif dim==2
  for j=1:size(x,dim)
    set(h,'CData',squeeze(x(:,j,:)));    
    set(gca,'clim',clim);
    pause(1/fr);    
    [k t kc] = KbCheck;
    if strcmp(KbName(kc),'q')
      break;
    end;
  end;
elseif dim==3
  for j=1:size(x,dim)
    set(h,'CData',x(:,:,j));    
    set(gca,'clim',clim);
    pause(1/fr);    
    [k t kc] = KbCheck;
    if strcmp(KbName(kc),'q')
      break;
    end;
  end;
end;