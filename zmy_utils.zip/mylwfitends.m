function yout = mylwfitends(yin,dim,sd,varargin)
%
% yout = mylwfitends(yin,dim,sd)
%
% Fit a curve to the data, yin, along the dimension, dim, by weighting the
% data locally around yin(i) with a Gaussian of standard deviation, sd, and
% fitting a straight line to the local data. Unlike mylwfit, mylwfitends
% does not pad either end of the data, but rather reduces the window size
% used for weighting the data near the ends.

% Process optional arguments
np = 0;
verbose = 0;
if nargin>3
  j = 1;
  while j<length(varargin)
    if strcmp(varargin{j},'parallel')
      np = varargin{j+1}; % # labs wanted for parallel threads
      if np>0
        cl = parcluster;
        cl.NumWorkers = 8;
        m = matlabpool('size'); % # of open labs
        if m==0
          matlabpool(cl,np);
        elseif m~=np
          matlabpool close;
          matlabpool(cl,np);
        end;
      end;
    elseif strcmp(varargin{j},'-v')
      verbose = varargin{j+1};
    end;
    j = j + 2;
  end;
end;

n = size(yin);

% Rearrange input shape
y = shiftdim(yin,(dim - 1)); % Make dimension 'dim' the first dimension
y = reshape(y,n(dim),prod(n)/n(dim)); 

% Find and remove any input data that has zero range along dimension dim
rmind = find(range(y,1)<(1e-15)); % Indices to remove from fitting
kpind = find(range(y,1)>=(1e-15));  % Indices to fit
yy = y;
yy(:,rmind) = [];

% Prepare output
z = zeros(size(yy));

% Integer sd
sdi = ceil(sd);

% Middle index into W and X
indm = ceil((10*sdi+1)/2);

% % Pad input for fitting lines near edges
% yy = cat(1,repmat(yy(1,:),[5*sdi,1]),yy,repmat(yy(end,:),[5*sdi,1]));

% Init weights
w = mygaussiann([10*sdi+1 1],[sd 0]); % Weights
W = diag(w); % Weights along diag of square matrix

% Prepare linear model
X = [(-(5*sdi):(5*sdi))', ones(10*sdi+1,1)];

% Compute local Gaussian weighted fits along dimension dim
if np>0 % If using parallel threads
  for j=1:floor(n(dim)/np)
    spmd
      
      % Determine min and max indeces in X and W, accounting for changing
      % window size near the ends.
      indmin = max(1,indm-j+1);
      indmax = min(10*sdi+1,indm-j+n(dim));
      % Select appropriate components of X and W, accounting for changing
      % window size near the ends
      eW = W(indmin:indmax,indmin:indmax);
      eX = X(indmin:indmax,:);
      % Find parameters by weighted least squares fit
      p = (X'*W*X)\X'*W*yy(((j-1)*np+labindex):((j-1)*np+labindex+10*sdi),:);
      p = p(2,:);
      % Use intercept parameters for the filtered data      
    end;
    if verbose, fprintf('j = %d of %d\n',j*np,n(dim)); end;
    for k=1:np
      z((j-1)*np+k,:) = p{k};
    end;
  end;
  if (n(dim) - j*np)>0
    for k=(j*np):n(dim)
      % Find parameters by weighted least squares fit
      p = (X'*W*X)\X'*W*yy(k:(k+10*sdi),:);
      % Use intercept parameters for the filtered data
      z(k,:) = p(2,:);
    end;
  end;
else % If not using parallel threads
  for j=1:n(dim)       
    if (j<indm)||(j>(n(dim)-indm+1))
      % Determine min and max indeces into X and W, accounting for changing
      % window size near the ends.
      indmin = max(1,indm-j+1);
      indmax = min(10*sdi+1,indm-j+n(dim));
      % Determine min and max indeces into yy, accounting for changing
      % window size near the ends.
      indminyy = max(1,j-indm+1);
      indmaxyy = min(n(dim),j+indm-1);
      % Select appropriate components of X and W, accounting for changing
      % window size near the ends
      eW = W(indmin:indmax,indmin:indmax);
      eX = X(indmin:indmax,:);
      % Find parameters by weighted least squares fit
      p = (eX'*eW*eX)\eX'*eW*yy(indminyy:indmaxyy,:);
    else
      indminyy = j - indm + 1;
      indmaxyy = j + indm - 1;
      % Find parameters by weighted least squares fit
      p = (X'*W*X)\X'*W*yy(indminyy:indmaxyy,:);
    end;    
    % Use intercept parameters for the filtered data
    z(j,:) = p(2,:);
    if verbose && mod(j,500)==1
      fprintf('j = %d of %d\n',j,n(dim));
    end;
  end;
end;

% Insert fits back into y
for j=1:length(kpind)
  y(:,kpind(j)) = z(:,j);
end;

% Reshape z to have same size as original input;
nn = circshift(n,[0 -(dim-1)]);
y = reshape(y,nn);
yout = shiftdim(y,length(nn)-dim+1);

if np>0
  matlabpool close;
end;