function [lsf param] = my_gauss_fit(dat)
%
% MY_GAUSS_FIT()
%
% Fit a 1D (2D) Gaussian curve (surface) to vector (image) data. 
% Returns the 1D (2D) least sqaures fit and coefficients.
% COEF = (COORD'*COORD)^-1 * COORD'*DAT; where COORD is the matrix of 
% data points.
%
% Inputs:
% DAT - data to fit
% 
% Outputs:
%  LSF - 1D (2D) least squares fit
% COEF - coefficients for the fit

ny = size(dat,1);
nx = size(dat,2);
 n = nx * ny;

 Y = repmat((1:ny)',[1 nx]); Y = Y(:);
Y2 = Y.^2;
 X = repmat((1:nx),[ny 1]); X = X(:);
X2 = X.^2;

if ny>1
  f = mygaussiann([9 9],[1.5 1.5]);
  f = f / sum(f(:));
else
  f = gaussian(3,0.5);
  f = f / sum(f(:));
end;

dat = conv2(dat,f,'same');
dat(dat<0) = 0;

dat = log(dat(:)); % Turn data into column vector


COORD = [X2 Y2 X Y ones(n,1)];

coef = eye(size(COORD'*COORD))/(COORD'*COORD) * COORD' * dat;

sdx = sqrt(-1/(2 * coef(1)));
sdy = sqrt(-1/(2 * coef(2)));

x0 = sdx.^2 * coef(3);
y0 = sdy.^2 * coef(4);

c = exp(coef(5) + ((x0/sdx)^2)/2 + ((y0/sdy)^2)/2);

param.sdx = sdx;
param.sdy = sdy;
param.x0 = x0;
param.y0 = y0;
param.c = c;

x = repmat(1:nx,[ny 1]);
y = repmat((1:ny)',[1 nx]);
lsf = 1 / sqrt(2*pi*sdx^2 * 2*pi*sdy^2) * ...
        exp(-(((y - y0)/sdy).^2 + ...
              ((x - x0)/sdx).^2)/2);
