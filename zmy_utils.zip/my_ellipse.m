function varargout = my_ellipse(y0,x0,smin,smaj,phi,h)

theta = 0:2*pi/500:2*pi;
x = x0 + smaj*cos(theta)*cos(phi) - smin*sin(theta)*sin(phi);
y = y0 + smin*sin(theta)*cos(phi) + smaj*cos(theta)*sin(phi);

if h
  g = plot(h,x,y);
end;
varargout{1} = g;
varargout{2} = x;
varargout{3} = y;
 