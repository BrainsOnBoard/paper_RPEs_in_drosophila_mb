function out = myfftshift(in)
%
% out = myfftshift(in)
%
% Performs circshift on IN to move the middle element to element 1 (in
% linear indexing format). Takes into account whether the dimensions of IN
% are even or odd numbered.

s = size(in);
out = circshift(in,-floor((s-1)/2));