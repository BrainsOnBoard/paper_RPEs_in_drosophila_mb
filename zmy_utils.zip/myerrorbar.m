function [h1 h2 h3] = myerrorbar(h,x,y,varargin)
%
% [H1 H2 H3] = MYERRORBAR(H,X,Y,E)
% X-Y scatter plot. Each point has error bars of magnitude E.
% Plots in axes with handle H.
% 
% [H1 H2 H3] = MYERRORBAR(H,X,Y,L,U)
% X-Y scatter plot. Each point has error bars with range:[Y-L, Y+U].
%
% [H1 H2 H3] = MYERRORBAR(H,X,Y,E,[],W)
% [H1 H2 H3] = MYERRORBAR(H,X,Y,L,U,[],W)
% X-Y scatter plot. Each point has error bars of magnitude E. 
% Errorbar tips span the x-axis by an amount W (default W = max(X)/50)
%
% H1, H2 & H3 are handles to the errorbars, errbar tips and central
% markers, respectively.

if numel(h)==0
  h = gca;
end;

if size(x)~=size(y)
  error('??? MYERRORBAR: X & Y must be same size');
end;

w = max(x(:))/50; % Default width of errorbar ends

if nargin>3
  nv = length(varargin);
  if nv==1
    l = y - varargin{1};
    u = y + varargin{1};
  elseif nv==2
    l = varargin{1};
    u = varargin{2};
  elseif nv==3
    l = y - varargin{1};
    u = y + varargin{1};
    w = varargin{3};
  elseif nv==4
    l = varargin{1};
    u = varargin{2};
    w = varargin{4};
  end;
else
  error('??? MYERRORBAR: Provide error value');
end;
    
% Make vectors [1xN]
if diff(size(x))<0
  x = x';
end;
if diff(size(y))<0
  y = y';
end;
if diff(size(l))<0
  l = l';
end;
if diff(size(u))<0
  u = u';
end;

% Plot
h1 = plot(h,[x;x],[l;u],'k');
hold on;
h2 = plot(h,[x-w;x+w],[l;l],'k',[x-w;x+w],[u;u],'k');
h3 = plot(h,x,y,'ko');

set(h3,'markersize',3,'markerfacecolor',[0 0 0]);
set(gca,'box','off');

hold off;