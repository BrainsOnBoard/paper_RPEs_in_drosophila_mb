function r2 = myr2(x,y,b0,b1,varargin)
%
% myr2(x,x0,x1)
% Compute R2 for linear fit.

y = y(:);
x = x(:);

if nargin>4
  w = varargin{1};
  w = w(:);
else
  w = ones(length(x),1);
end;

%%% Total sum of squares
stot = sum(w.*(y - mean(y)).^2);

%%% Sum of squared residuals
sres = sum(w.*(y - (b0 + b1*x)).^2);

r2 = 1 - sres/stot;