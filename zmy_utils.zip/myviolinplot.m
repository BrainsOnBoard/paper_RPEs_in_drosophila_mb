function varargout = myviolinplot(x,data,edgedelta,scale,sd,varargin)

% Make vectors that will be used to draw a curve outlining the histogram
nx = length(x);

hh = cell(nx,1);
h = cell(nx,1);
eh = cell(nx,1);
eb = cell(nx,1);
% Build histogram from data
for j=1:nx  
  [eh{j} eb{j}] = myhe(min(data(:,j))-max(edgedelta,0.1*range(data(:,j))),...
                 edgedelta,...
                 max(data(:,j))+max(edgedelta,0.1*range(data(:,j))));
  hh{j} = histc(data(:,j),eh{j},1); 
  hh{j} = hh{j} ./ sum(hh{j},1); hh{j}(end) = [];
  
  % Smooth histogram
  h{j} = mylwfitends(hh{j},1,sd);
end;

deb = edgedelta;

hgram = cell(nx,1);
y = cell(nx,1);
for j=1:nx
	y{j} = zeros(length(eb{j})*2 + 2,1);
	hgram{j} = zeros(length(eb{j})*2 + 2,1);
	y{j}(1) = eb{j}(1)-deb/2;
	hgram{j}(1,:) = 0;
end;

for k=1:nx
  for j=2:(1+(length(eb{k}))*2)    
    hgram{k}(j) = h{k}(ceil((j-1)/2));
  end;
	for j=2:(1+(length(eb{k}))*2)
		if mod(j,2)==0
			y{k}(j) = y{k}(j-1);
		else
			y{k}(j) = y{k}(j-1) + deb;
		end;
	end;
	y{k}(end) = eb{k}(end) + deb/2;
	y{k} = [y{k}; y{k}(1)];
	hgram{k}(end,:) = 0;
	hgram{k} = [hgram{k}; 0];
	hgram{k} = max(0,hgram{k});	
	
	% Scale the width of the histograms for visibility
	hgram{k} = hgram{k} / 2 * scale;
end;

% Parse other plotting options
c = 'k';
l = 0.5;
j = 1;
if nargin>5
  while j<=(nargin-5)
    if strcmp(varargin{j},'color')
      c = varargin{j+1}; j = j + 2;
    end;
  end;
end;

% Plot histograms
for j=1:nx
  ha(j,1) = patch(x(j)+hgram{j},y{j},c);
	set(ha(j,1),'linestyle','none');
  hold on;
  ha(j,2) = patch(x(j)-hgram{j},y{j},c);
	set(ha(j,2),'linestyle','none');
end;
hold off;

mx = 0;
for j=1:nx
	if max(hgram{j})>mx
		mx = max(hgram{j});
	end;
end;

set(gca,'xlim',[min(x)-mx/2*scale, max(x)+mx/2*scale]);

varargout{1} = ha;