function o=mytemp()

t1=3;
t2=10;
eta1=9e-1; 
eta2=3e-1; 
eta3=5e-1; 

nt = 600;
rr = zeros(nt,1); 
rr(101:end) = 2 ; 
sigma = 0;
r = mygfilter(rr,[sigma 0],[10*sigma 0]) + .1*randn(nt,1); 

pe=zeros(nt,1); 
se1=zeros(nt,1);
se2=zeros(nt,1);
e=zeros(nt,1);

for j=1:(nt-1) 
  pe(j+1) = (r(j) - e(j)); 
  se1(j+1)=se1(j)*exp(-1/t1) + (r(j) - e(j))/t1;  
  se2(j+1)=se2(j)*exp(-1/t2) + (r(j) - e(j))/t2;  
%   e(j+1) = e(j) + eta1*pe(j) + eta2*se1(j) + eta3*(se1(j)-se2(j)); 
  e(j+1) = e(j) + eta1*pe(j) + eta2*se1(j) - eta3*se2(j); 
end;

o.r=r;
o.rr=rr;
o.pe=pe;
o.se1=se1;
o.se2=se2;
o.e=e;

plot(r);
hold on;
plot(e,'r--');
% plot(5+gradient((r-e),1),'m');
% plot(5+pe,'g');
plot(5+se1,'b');
plot(5+se2,'c');
plot(5+se1-se2,'k--');
hold off;