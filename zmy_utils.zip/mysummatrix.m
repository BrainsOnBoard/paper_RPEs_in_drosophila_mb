function a = mysummatrix(varargin)

if nargin==1
  b = varargin{1};
  n = length(b);
  a = zeros(n);
  for j=1:n
    a(:,j) = b(j) + b;
  end;
  
elseif nargin==2
  b = varargin{1};
  c = varargin{2};
  nb = length(b);
  nc = length(c);
  a = zeros(nc,nb);
  for j=1:nb
    a(:,j) = b(j) + c;
  end;
end;