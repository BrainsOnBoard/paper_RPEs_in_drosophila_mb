function im = myim2blue(im)

im = uint8(mean(im,3));
im = cat(3,uint8(zeros(size(im,1),size(im,2))),repmat(im,1,1,2));