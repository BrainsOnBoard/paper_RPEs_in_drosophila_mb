function y = myfishtran(x)
%
% Outputs the Fisher transformed x

y = 0.5 * log((1 + x) ./ (1 - x));