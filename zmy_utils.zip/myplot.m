function varargout = myplot(varargin)
%
%For use when plotting a single dimension from an N-dimensional array.
%Works in the same way as PLOT.
%See also PLOT.

if nargin==1
  if nargout>0
    varargout{1} = plot(squeeze(varargin{1}));    
  else
    plot(squeeze(varargin{1}));
  end;     
end;
if nargin==2
    if ischar(varargin{2})
        L = length(varargin{1});
        vec = zeros(1,L);
        vec(:) = varargin{1}(:);
        if nargout > 0
          varargout{1} = plot(vec,varargin{2});
        else
          plot(vec,varargin{2});
        end;
    else
        L1 = length(varargin{1}); %number of x-values
        vec1 = zeros(1,L1);
        vec1(:) = varargin{1}(:); %vector of x-values
        L2 = length(varargin{2}); %number of y-values
        if L2~=L1
            error('Vectors must be the same length');
        end;
        vec2 = zeros(1,L2);
        vec2(:) = varargin{2}(:); %vector of y-values
        if nargout > 0
          varargout{1} = plot(vec1,vec2);
        else
          plot(vec1,vec2);
        end;
    end;
end;
if nargin==3
    L1 = length(varargin{1}); %number of x-values
    vec1 = zeros(1,L1);
    vec1(:) = varargin{1}(:); %vector of x-values
    L2 = length(varargin{2}); %number of y-values
    if L2~=L1
        error('Vectors must be the same length');
    end;
    vec2 = zeros(1,L2);
    vec2(:) = varargin{2}(:); %vector of y-values
    if nargout > 0
      varargout{1} = plot(vec1,vec2,varargin{3});
    else
      plot(vec1,vec2,varargin{3});
    end;
end;
    