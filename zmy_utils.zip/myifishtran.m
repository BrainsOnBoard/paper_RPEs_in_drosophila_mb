function y = myifishtran(x)
%
% Outpus inverse Fisher transformed x

y = (exp(2 * x) - 1) ./ (exp(2 * x) + 1);