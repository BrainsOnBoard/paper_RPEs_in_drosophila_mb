function myprint(fig,format,fname)
%
% myprint(fig,fname)
%
% Print colour eps to .eps file with no cropping.
%
% Inputs:
%    fig - figure number
% format - image format, e.g. 'epsc'
%  fname - name of file

figure(fig);

dformat = ['-d' format];

[v d] = version; 
d = str2num(d(end-3:end));

if d<2017
	if strcmp(format,'epsc')
		print(dformat,'-r400','-loose','-tiff','-painters',fname);
%     print(dformat,'-r400','-loose','-tiff',fname);
	elseif strcmp(format,'svg')
		print(dformat,'-r400','-loose','-painters',fname);
	elseif strcmp(format,'-dtiff')
		print(dformat,'-r400',fname);
	else
		print(dformat,'-r400','-loose',fname);
	end;
else
	if strcmp(format,'epsc')
		print(fname,dformat,'-r400','-loose','-tiff','-painters');
	elseif strcmp(format,'svg')
		print(fname,dformat,'-r400','-loose','-painters');
	elseif strcmp(format,'-dtiff')
		print(fname,dformat,'-r400');
	else
		print(fname,dformat,'-r400','-loose');
	end;
end;