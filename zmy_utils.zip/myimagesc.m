function h = myimagesc(I,varargin)
%
% MYIMAGE(I,CLIM)
% Draw scaled image, as with IMAGESC, but is able to handle a slice
% from n-dimensional data
%
% Inputs: 
%    I - image
% CLIM - [upper lower] limits to specify scaling
%      - default: [min(I(:)) max(I(:))]

n = size(I);
j = 1;
while j<numel(n)
  if n(j)==1
    n(j) = [];
    j = j - 1;
  end;
  j = j+1;
end;
if numel(n)~=2
  error('***MYIMAGESC: image must be a 2D slice');
end;

clim = [min(I(:)) max(I(:))];
if nargin>1
  clim = varargin{1};
end;
A = zeros(n(1),n(2));
A(:,:) = I;
h = imagesc(A,clim);