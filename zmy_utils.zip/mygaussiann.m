function g = mygaussiann(dims,sd,varargin)

if length(dims)~=length(sd)
  error('???MYGAUSSIANN: size(dims) must equal size(sd)');
end;
ndim = length(dims); % number of dimensions
g = ones(dims);

%%% Options
flag_shift = false;
flag_max1 = false;
if nargin>2
  j = 1;
  while j<=length(varargin)
    if strcmp(varargin{j},'shift')      
      % Shift Gaussian centre for computing Fourier transform
      flag_shift = true;      
      j = j + 1;
    elseif strcmp(varargin{j},'max1')
      % Make maximum value of g equal to 1
      flag_max1 = true;      
      j = j + 1;
    elseif strcmp(varargin{j},'centre')
      centre = varargin{j+1};
      j = j + 2;
    end;
  end;
end;

%%% Create Gaussian
if ~exist('centre','var')
  centre = (dims+1)/2;
end;
for j=1:ndim
  x = 1:dims(j);      % Coords  
  x2 = centre(j); % Centre of Gaussian
  s = sd(j);          % SD along dimension j
  
  if ((s~=inf) && (s>0))
    % Create Gaussian
    gg = 1 / (s * sqrt(2*pi)) * exp(-((x-x2)/s).^2/2);
    % Reshape Gaussian along dimension j
    gg = reshape(gg,[ones(1,j-1), dims(j), ones(1,ndim-j)]);
    % Repeat Gaussian along other dimensions, multiply with g
    g = g .* repmat(gg,[dims(1:j-1), 1, dims(j+1:end)]);
  elseif s==inf
    % To ensure Gaussian is properly normalised
    g = g / dims(j);
  elseif s==0    
    gg = zeros(1,dims(j));
    gg(floor((dims(j)+1)/2)) = 1;
    gg = reshape(gg,[ones(1,j-1), dims(j), ones(1,ndim-j)]);
    g = g .* repmat(gg,[dims(1:j-1), 1, dims(j+1:end)]);
  end;
end;

if flag_shift
  g = circshift(g,-floor((dims-1)/2));
end;
if flag_max1
  g = g / max(g(:));
end;
