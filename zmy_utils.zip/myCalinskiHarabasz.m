function [CH, varargout] = myCalinskiHarabasz(x,c)
%
% Compute the Calinski-Harabsz function for pre-clustered data
% Inputs:
%  x - array of the raw data. Rows are observations, columns are variables
%  c - array of cluster IDs; length(c) must equal size(x,1)
% Outpus:
%  CH - the Calinski-Harabasz index

% Check if length(c)==size(x,1)
if length(c)~=size(x,1)
  error('??? myCalinskiHarabasz: size(c) must equal size(x).');
end;

% Number of clusters
nc = max(c);
if nc<2
  error('??? myCalinskiHarabasz: number of clusters must exceed 1.');
end;
% Number of dimensions
ndims = size(x,2);
% Total number of observations
nobs = size(x,1);

% Global mean
mu = mean(x,1);

% Compute Between-cluster and Within-cluster variances
mu_cl = zeros(nc,ndims); % Init cluster means
n_cl = zeros(nc,1); % Init cluster sizes
W = 0; % Init Within cluster variance
for j=1:nc
  temp = x(c==j,:);
  mu_cl(j,:) = mean(temp,1);  
  n_cl(j) = numel(temp); 
  
  W = W + sum(sqrt(sum((temp - ones(size(temp,1),1) * mu_cl(j,:)).^2,2)));
end;

% Between cluster variance
B = sum(n_cl .* sqrt(sum((mu_cl - ones(nc,1)*mu).^2,2)));

% Compute CH index
CH = B / W * (nobs - nc) / (nc - 1);

if nargout>1
  varargout{1} = W;
end;
if nargout>2
  varargout{2} = B;
end;