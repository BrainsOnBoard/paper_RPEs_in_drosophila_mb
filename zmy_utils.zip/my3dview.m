function my3dview(newfig,a,varargin)
%
% my3dview(newfig,a)
%
% Open a 3D image in a viewer that allows manual control of which slice
% along the 3rd dimension to view.
%
% ***Inputs***
%  newfig: 0 - open image in current viewer; 1 - open new 3d viewer
%       a: 3D image
%
% ***Optional input***
% my3dview(newfig,a<,cmap><,[low high]>)
%
%       cmap: colormap
% [low high]: low and high limits

%%%% Parse Inputs
a = squeeze(a);
if ndims(a)~=3
  error('??? MY3DVIEW: my3dview is intended for 3d data only');
end;
if nargin>3
  lim = varargin{2};
  low = lim(1); high = lim(2);
else
  low = min(a(:));
  high = max(a(:));
end;

if newfig
  %%%%
  %%%% Set up GUI
  %%%%
  scr = get(0,'monitorpositions');
  
  %%%% Figure
  F = figure('name','MY3DVIEW','numbertitle','off','menubar','figure');
  F.Position = [1, scr(4)-600, 660, 600];
  
  %%%% Axes
  A = axes('units','pixels','xtick',[],'ytick',[]);
  A.Position = [1 1 600 600];
  
  %%%% Viewed slice
  s = uicontrol('parent',F,...
    'style','slider',...
    'position',[620 25 20 500]);
  t = uicontrol('parent',F,...
    'style','text',...
    'string','Slice',...
    'position',[605 530 50 15]);   
end;

%%%% Callbacks
s.Callback = {@slicenum,a,[low high],t};
  
% Setup slider for new 3D image
s.Min = 1;
s.Max = size(a,3);
s.SliderStep = [1 10]/(size(a,3)-1);
s.Value = ceil(size(a,3)/2);
t.String = ['Slice ' num2str(s.Value)];

%%%% Parse colormap input
if nargin>2
  colormap(varargin{1});
else
  colormap(jet);
end;

%%%% Initialise image
imagesc(a(:,:,s.Value),[low high]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function slicenum(src,data,im,lim,txt)

src.Value = ceil(src.Value);
im = im(:,:,src.Value);
imagesc(im,[lim(1) lim(2)]);
txt.String = ['Slice ' num2str(src.Value)];