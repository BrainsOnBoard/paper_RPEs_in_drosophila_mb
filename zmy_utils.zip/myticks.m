function myticks(varargin)
%
% MYTICKS(VARARGIN)
% Set size of tick marks so that they are actually visible in publication grade figures.
% Make them point outwards so that plotted data doesn't obscure them. 
% Option to provide handle to axes.

if nargin>0
  j = 1;
  while j<nargin
    if strcmp(varargin{j},'ax')
      ah = varargin{j+1}; % Axes handle
    elseif strcmp(varargin{j},'fig')
      fh = varargin{j+1}; % Figure handle
    end;
    j = j + 2;
  end;
  pp = get(fh,'paperposition'); % Paperposition
  set(ah,'tickdir','out','ticklength',[0.2/max(pp(3:4)) 0]);

  ch = findobj(fh,'tag','Colorbar'); % colorbar handle
  if ~isempty(ch) % if colorbar
    set(ch,'tickdir','out','ticklength',[0.3/max(pp(3:4)) 0]);
  end;
else
  pp = get(gcf,'paperposition'); % Paperposition
  set(gca,'tickdir','out','ticklength',[0.2/max(pp(3:4)) 0]);
  
  ch = findobj(gcf,'tag','Colorbar'); % colorbar handle
  if ~isempty(ch) % if colorbar
    set(ch,'tickdir','out','ticklength',[0.3/max(pp(3:4)) 0]);
  end;
end;