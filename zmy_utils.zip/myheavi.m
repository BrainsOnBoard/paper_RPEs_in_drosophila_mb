function out = myheavi(in)

out = zeros(size(in));
out(in>0) = 1;
