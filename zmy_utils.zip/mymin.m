function m = mymin(x)
%
% Returns the global minumum

m = min(x(:));