function m = mymax(x)
%
% Returns the global maximum

m = max(x(:));