function B = incres3d(A,scale)
%
% B = incres3d(A,scale)
%
% Increases the resolution (without anti-aliasing) of A such that
% size(B) = scale * size(A).

scale = scale - 1;

B = A;
for j=1:scale
  B = cat(1,B,A);
end;
ind1 = 1:size(B,1);
ind2 = [1:2:max(ind1),2:2:max(ind1)];

B(ind2,:,:) = B(ind1,:,:);
A = B;

for j=1:scale
  B = cat(2,B,A);
end;
ind1 = 1:size(B,2);
ind2 = [1:2:max(ind1),2:2:max(ind1)];

B(:,ind2,:) = B(:,ind1,:);
A = B;

for j=1:scale
  B = cat(3,B,A);
end;
ind1 = 1:size(B,3);
ind2 = [1:2:max(ind1),2:2:max(ind1)];

B(:,:,ind2) = B(:,:,ind1);