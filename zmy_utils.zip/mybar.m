function ha = mybar(eb,h,varargin)
%
% MYBAR(EB,Y)
%
% Plot a bar graph, showing only the outer outline of the bars, i.e. 
% vertical lines separating bars are not shown.
%
% Inputs:
% EB - x-positions for bar edges, obtained using HE()
%  H - histogram values
%
% Options:
% 'style' - 'normal', 'outline', 'area', 'categorical'
% 'color'
% 'linewidth'
% 'errorbar'

x = zeros(length(eb)*2 + 2,1);
y = zeros(length(eb)*2 + 2,1);

deb = diff(eb(1:2));
x(1) = eb(1)-deb/2;
y(1) = 0;

for j=2:(1+(length(eb))*2)
  if mod(j,2)==0
    x(j) = x(j-1);
  else
    x(j) = x(j-1) + deb;
  end;
  y(j) = h(ceil((j-1)/2));
end;

x(end) = eb(end) + deb/2;
y(end) = 0;

c = 'b';
l = 0.5;
j = 1;
s = 'normal';
w = 0.9;
if nargin>2
  while j<=(nargin-2)
    if strcmp(varargin{j},'color')
      c = varargin{j+1}; j = j + 2;
    elseif strcmp(varargin{j},'linewidth')
      l = varargin{j+1}; j = j + 2;
    elseif strcmp(varargin{j},'style')
      s = varargin{j+1}; j = j + 2;
    elseif strcmp(varargin{j},'barwidth')
      w = varargin{j+1}; j = j + 2;
    elseif strcmp(varargin{j},'errorbar')
      if numel(varargin{j+1})==2
        er1 = varargin{j+1}{1};
        er2 = varargin{j+1}{2};
      else 
        er1 = varargin{j+1};
        er2 = varargin{j+1};
      end;
      j = j + 2;
    else 
      error('???mybar: Argument %d not recognised',j);
    end;
  end;
end;

if strcmp(s,'normal')
  ha = bar(eb,h,w,'facecolor',c,'edgecolor',c);
  if exist('er1','var')
    hold on;
    for j=1:length(h)
      he = plot([eb(j),eb(j)],[h(j)+er1(j),h(j)-er2(j)]);
      set(he,'color',[0 0 0],'linewidth',l);
    end;
    hold off;
  end;
elseif strcmp(s,'outline')
  ha = plot(x,y,'linewidth',l);
  set(ha,'color',c);
elseif strcmp(s,'area')
  ha = area(x,y,'facecolor',c,'linestyle','none');
elseif strcmp(s,'categorical')
  ha = bar(eb,h,w,'facecolor',c,'edgecolor',c);
  if exist('er1','var')
    hold on;
    for j=1:length(h)
      he = plot([eb(j),eb(j)],[h(j)+er1(j),h(j)-er2(j)]);
      set(he,'color',[0 0 0],'linewidth',l);
    end;
    hold off;
  end;
end;
