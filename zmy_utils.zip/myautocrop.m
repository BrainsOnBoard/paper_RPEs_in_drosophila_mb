function [c, b] = myautocrop(im,varargin)
%
% [c, b] = myautocrop(im)
%
% Crop the image matrix, IM, to the smallest N-dimensional hyperrectangle
% that ENCLOSES all non-zero data in IM. C is the cropped N-dimensional
% image. B is the bounding box info that can be used to crop other volumes
% to the same region. B is a 1x6 vector, where B(1:3) gives the edge of the
% box along the 1st, 2nd and 3rd dimensions, respectively, for which 
% floor(B(1:3)) ENCLOSES the data, rather than lies on its outermost edge; 
% B(4:6) gives the size of the box along the 1st, 2nd and 3rd dimensions, 
% respectively, i.e. ceil(B(1:3)+B(4:6)) define the planes of the
% box that enclose the data.
%
% c = myautocrop(im,b)
%
% Crop the image matrix, IM, using the bounding box in B.

n = ndims(im);

if nargin<2  
  % Find bounding hyperrectangle
  b = regionprops(im>0,'boundingbox');
  b = b.BoundingBox;
  
  % BoundingBox has the order [x,y,...dx,dy,....], so swap x and y dims
  a1 = b(1); a2 = b(2);
  b(1) = a2; b(2) = a1;
  a1 = b(n+1); a2 = b(n+2);
  b(n+1) = a2; b(n+2) = a1;
end;
if nargin==2
  b = varargin{1};
end;

% Bounding box mask
m = ones(b(n+1:end)); % Bounding box mask
m = padarray(m,size(im)-size(m),0,'post');
m = circshift(m,floor(b(1:n)));

% Cropped image
c = im(m>0);
c = reshape(c,b(n+1:end));
