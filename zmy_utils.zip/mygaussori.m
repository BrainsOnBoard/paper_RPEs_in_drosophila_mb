function f = mygaussori(ny,nx,sy,sx,yo,xo,phi)
%
% F = MYGAUSSORI(NY,NX,SY,SX,YO,XO,PHI)
%
% F is a 2D Guassian surface that can be oriented relative to the 
% x-axis.
%
% Inputs:
%  NY - size in y-direction
%  NX - size in x-direction
%  SY - standard deviation along y-axis
%  SX - standard deviation along x-axis
%  YO - Gaussian centre along y-axis
%  XO - Gaussian centre along x-axis
% PHI - rotation relative to x-axis (degrees)
%
% Outpus:
% F - matrix containing the 2D Gaussian surface

[xi yi] = meshgrid(1:nx,1:ny); % x- and y-coordinates

phi = phi / 360 * 2 * pi;

a = (cos(phi)^2 / (2 * sx^2)) + (sin(phi)^2 / (2 * sy^2));
b = - (sin(2 * phi) / (2 * sx^2)) + (sin(2 * phi) / (2 * sy^2));
c = (sin(phi)^2 / (2 * sx^2)) + (cos(phi)^2 / (2 * sy^2));

f = exp(-a*(xi - xo).^2 - b*(xi - xo).*(yi - yo) - c*(yi - yo).^2);

f = f / sum(f(:));