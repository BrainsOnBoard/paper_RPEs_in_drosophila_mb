function varargout = myiminfo(nmax,varargin)
%
% varargin:
% nmax - max # of images to process
% 'dir' - save info from 'pics' directory
% 'subdir' - save info from sub-directories

if nargout~=(nargin-1)
  error('??? MYIMINFO: #outputs must equal the # requested');
end;

dbstop if error

cd ~/Documents/pics/;

d = dir;
dd = cell(100,1); % For saving sub-directory info
dircount = 0;
for j=6:length(dir)
  if d(j).isdir
    dircount = dircount + 1;
    dirind(dircount) = j;
  end;
end;

dirnames = cell(dircount,1);
for j=1:dircount
  dirname{j} = d(j).name;
end;

FL = []; % Focal length (35mm equivalent)
ET = []; % Exposure time (s)
FN = []; % F-number
piccount = 1;
subdircount = 1;
ind = 6; 
% Run through everything in 'pics' directory
while ind<=length(d)
  % Process images in sub-directories
  if d(ind).isdir    
    dd{subdircount} = dir(d(ind).name);
    cd(d(ind).name);
    subind = 1;
    while subind<=length(dd{subdircount})
      % If not a directory, and the image is unedited, take details
      if ~dd{subdircount}(subind).isdir && length(dd{subdircount}(subind).name)==12 && strcmp(dd{subdircount}(subind).name(1),'P') && strcmp(dd{subdircount}(subind).name(end-2:end),'JPG')
        im = imfinfo(dd{subdircount}(subind).name);
        FL(piccount) = im.DigitalCamera.FocalLengthIn35mmFilm;
        ET(piccount) = im.DigitalCamera.ExposureTime;
        FN(piccount) = im.DigitalCamera.FNumber;
        piccount = piccount + 1;
        if mod(piccount,500)==0
          fprintf('Pic %d complete\n',piccount);
        end;
      end;
      subind = subind + 1;
    end;
    cd ..;
    subdircount = subdircount + 1;
  else
    % Process images in the 'pics' directory
    if ~d(ind).isdir && length(d(ind).name)==12 && strcmp(d(ind).name(1),'P') && strcmp(d(ind).name(end-2:end),'JPG')
      im = imfinfo(d(ind).name);
      FL(piccount) = im.DigitalCamera.FocalLengthIn35mmFilm;
      ET(piccount) = im.DigitalCamera.ExposureTime;
      FN(piccount) = im.DigitalCamera.FNumber;
      piccount = piccount + 1;
      if mod(piccount,500)==0
        fprintf('Pic %d complete\n',piccount);
      end;
    end;
  end;
  ind = ind + 1;
  if piccount>nmax
    break;
  end;
end;
cd ~/Documents/MATLAB/;

% Compute histograms
[eh eb et] = myhe(10,10,400);
myfig(10,10);
h = histc(FL,eh); h = h/sum(h); h(end-1:end) = [];
subplot(3,1,1);
mybar(eb,h,'color','r');
[eh eb et] = myhe(0,1/500,1);
h = histc(ET,eh); h = h/sum(h); h(end-1:end) = [];
subplot(3,1,2);
mybar(eb,h,'color','g');
[eh eb et] = myhe(0,0.5,20);
h = histc(FN,eh); h = h/sum(h); h(end-1:end) = [];
subplot(3,1,3);
mybar(eb,h,'color','b');

if nargout>0  
  varargout = cell(nargout,1);
  for j=1:nargout
    if strcmp(varargin{j},'dir')
      varargout{j} = d;
    end;
    if strcmp(varargin{j},'subdir')
      varargout{j} = dd;
    end;
    if strcmp(varargin{j},'data')
      data.FL = FL;
      data.ET = ET;
      data.FN = FN;
      varargout{j} = data;
    end;
  end;
end;